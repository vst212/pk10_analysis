__author__ = 'shifeixiang'
map = {}
map["name"] = "ss"
map["pwd"] = "123"
print map