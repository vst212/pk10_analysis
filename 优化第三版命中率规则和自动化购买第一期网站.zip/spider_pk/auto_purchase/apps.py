# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class AutosPurchaseConfig(AppConfig):
    name = 'auto_purchase'
