# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class AutoPxiagme1PurchaseConfig(AppConfig):
    name = 'auto_pxiagme1_purchase'
